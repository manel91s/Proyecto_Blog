<?php $__env->startSection('section'); ?>

<h1>Manel Aguilera Martinez</h1>

<h3 class="h3">Full Stack Junior Developer</h3>

<div id="container-about">

<p>Mi pasión es el desarrollo web y la tecnología, actualmente soy estudiante de grado superior de informática aunque tengo a mi disposición el certificado de profesionalidad superior de nivel 3 de desarrollador de aplicaciones con tecnología web. Me considero una persona al que le gusta los nuevos objetivos y poder aprender de ellos, así como tener la posibilidad de desenvolverme en cualquier proyecto que se me disponga.</p><br><br>

<p>Aunque mi experiencia laboral en este sector es mínima considero tener conocimientos necesarios para poder llevar a cabo proyectos que se me asignen. </p><br><br>

<p>Conocimientos en Full Stack Web con tecnologías como:  </p><br>

<p><strong>HTML5, CSS3, BOOSTRAP4, JS ECMA6, AJAX, JAVA, ANGULAR, PHP, MVC, LARAVEL 5+...</strong> </p>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>