<?php $__env->startSection('section'); ?>

<h2>Gestionar Entradas</h2>

<?php if(Session::has('success')): ?>
    <p class="alert-success center-text"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<table id="allPost">



</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>