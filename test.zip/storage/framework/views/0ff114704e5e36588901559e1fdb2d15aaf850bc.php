
<?php echo $__env->make('layout-front.front_blade', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>