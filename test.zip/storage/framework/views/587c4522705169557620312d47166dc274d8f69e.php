<?php $__env->startSection('section'); ?>


<div class="container-movie">
<?php for($i=0; $i < sizeof($detailCategory); $i++): ?>

<div>
<a href="<?php echo e(route('detail.post',$detailCategory[$i]->id)); ?>"><img src="<?php echo e(asset('imagesCover/'.$detailCategory[$i]->cover)); ?>" alt=""></a>
<p><?php echo e($detailCategory[$i]->title); ?></p>

</div>
<div>
<?php endfor; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>