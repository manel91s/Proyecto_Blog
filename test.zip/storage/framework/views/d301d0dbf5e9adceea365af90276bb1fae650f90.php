<!DOCTYPE html>
<html lang="es" class="">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Final - <?php echo $__env->yieldContent('titulo'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset("css/style.min.css")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <header>
        <?php $__env->startSection('header'); ?>
        
        <h1>Blog<span>.</span></h1>
        <nav>
           <ul>
               <li><a href="">Inicio</a></li>
               <li><a href="">Acerca de </a></li>
               <li><a href="">Contacto</a></li>
           </ul>
            
        </nav>


        <?php echo $__env->yieldSection(); ?>
    </header>

    <nav>

    </nav>

    <div class="container">
        <section>
            <?php echo $__env->yieldContent('section'); ?>
        </section>

        <aside>
            <?php echo $__env->yieldContent('aside'); ?>
        </aside>
    </div>


    <footer>
        <h2>Blog</h2>
        <p>&copy; Blog.com - Todos los derechos reservados - <span>Desarrollado por Manel</span></p>
        <div>
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-linkedin"></a> 
        <a href="#" class="fa fa-instagram"></a> 
        </div>
         
    </footer>


</body>

</html>