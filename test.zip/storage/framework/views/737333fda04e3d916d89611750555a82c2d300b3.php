<?php $__env->startSection('section'); ?>

<p>prueba</p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>