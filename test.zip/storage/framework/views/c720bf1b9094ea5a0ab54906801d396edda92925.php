<?php use App\Custom\Utils ?>




<?php $__env->startSection('section'); ?>

<h1 class="padding-20px-bottom">Crear entradas de peliculas</h1>
<form action="<?php echo e(action('PostController@save')); ?>" method="post" enctype="multipart/form-data">


  

    <?php echo e(csrf_field()); ?>

    <?php $user = session('login') ?>
    <?php if(session()->has('login')): ?>
    <p>
        <input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">
    </p>
  

    <p>
        <label for="name">Categoria de la entrada</label>
    </p>

    <p>
        <?php $categorys = Utils::showCategorias() ?>
       
        <select name="id_category" id="id_category">
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p class="alert-warning"><?php echo e($errors->first('id_category')); ?></p>
    </p>

    <p class="margin-10px-top"> 
        <label for="imagen">Subir imagen de la entrada</label> <br/>
        <input type="file" name="image"> 
        <p class="alert-warning"><?php echo e($errors->first('image')); ?></p>
    </p>

    <p class="margin-10px-top">
        <label for="image">Subir imagen de la caratula</label><br/>
        <input type="file" name="cover">
        <p class="alert-warning"><?php echo e($errors->first('cover')); ?></p>
    </p>
  

    <p class="margin-10px-top">
        <label for="title">Titulo</label>
        <input type="text" name="title" placeholer="Apellidos">
        <p class="alert-warning"><?php echo e($errors->first('title')); ?></p>

    </p>

    <p class="margin-10px-top">
        <label for="featured">Entrada Destacada</label><br/>
       
        <input type="radio" id="featured" name="featured" value="1" checked>
        <label class="margin-10px-right" for="featrued">Si</label>
        <input type="radio" id="" name="featured" value="2">
        <label for="featured">No</label>
    </p>

    <p class="margin-10px-top">
        <label for="body">Cuerpo del texto</label><br/>
        <textarea name="body" id="body" cols="30" rows="20"></textarea>
        <p class="alert-warning"><?php echo e($errors->first('body')); ?></p>
    </p>
    <?php endif; ?>

  


    <?php if(Session::has('success')): ?>
    <p class="alert-success"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>

    <input type="submit" value="Enviar">
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>