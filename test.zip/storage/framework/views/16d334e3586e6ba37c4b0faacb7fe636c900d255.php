<?php use App\Custom\Utils ?>
<?php use Illuminate\Pagination\Paginator ?>


<?php $__env->startSection('section'); ?>


<?php for($i=0; $i< sizeof($detailPost); $i++): ?>
    <article class="padding-40px-bottom">
        <img src="<?php echo e(asset('images/'.$detailPost[$i]->image)); ?>" alt="">
        
        <div>
        <h1><?php echo e($detailPost[$i]->title); ?></h1>
        <p>Genero : <span class="text-bold"><?php echo e($detailPost[$i]->name_category); ?></span></p>
        <p><?php echo e($detailPost[$i]->body); ?></p>
        <p>Posteado por: <span class="text-bold"><?php echo e($detailPost[$i]->name_user); ?></span></p>

        </div>
  </article>
  <?php endfor; ?>

       
        <?php $commentUser = Utils::showCommentsByPost($detailPost[0]->id) ?>
        <?php for($i=0; $i < sizeof($commentUser); $i++): ?>
        <div class="comments margin-50px-bottom">
        <div id="container-photo">
        
        <?php if($commentUser[$i]->role_name=='Admin'): ?>
            <?php $roleClass = "photoAdmin"; ?>
            <?php else: ?>
            <?php $roleClass=""; ?>
            <?php endif; ?>

        <?php if($commentUser[$i]->avatar_url!=null): ?> 
        <img class="avatar_image <?php echo e($roleClass); ?>" src="<?php echo e(asset('avatar_img/'.$commentUser[$i]->avatar_url)); ?>"  alt=""> 
        <?php else: ?>
        <img src="" alt="">
        <?php endif; ?>

        <p class="role-color text-bold"><?php echo e($commentUser[$i]->role_name); ?></p>
        <span class="text-bold"><?php echo e($commentUser[$i]->name); ?></span>
        </div>
        <div id="container-comment">
        <p><?php echo e($commentUser[$i]->created_at); ?></p>
        <p><?php echo e($commentUser[$i]->description); ?></p>
        </div>


        </div>

        <?php endfor; ?>
        
      
        <?php echo e($commentUser->links()); ?>

        


        <?php for($i=0; $i< sizeof($detailPost); $i++): ?>
        <?php if(session()->has('login')): ?>
        <form action="<?php echo e(action('CommentController@create')); ?>" method="POST" class="form-comment padding-80px-bottom">
        <?php echo e(csrf_field()); ?>

       
        <h2>Pon tu comentario</h2>
       
        <?php $user = session()->get('login')  ?>
        <input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">
        <input type="hidden" name="id_post" value="<?php echo e($detailPost[$i]->id); ?>">
       
       
        <textarea class="padding-20px-top" name="description" id="" cols="30" rows="20"></textarea>
        <p class="alert-warning"><?php echo e($errors->first('description')); ?></p>
        <input type="submit" value="Enviar">
        </form>
        <?php else: ?>

        <p>Quieres dejar un comentario? Registrate!</p>

        <?php endif; ?>

        <?php endfor; ?>
        
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>