<?php use App\Custom\Utils;?>





<?php $__env->startSection('section'); ?>
<h1 class="padding-20px-bottom"> Crear Categoria</h1>

<form action="<?php echo e(action('CategoryController@create')); ?>" method="post">

        <?php echo e(csrf_field()); ?>

    <p>
        <label for="name">Nombre Categoria</label>
        <input type="text" name="name" placeholer="Nombre">
        <p class="alert-warning"><?php echo e($errors->first('name')); ?></p>
    </p>


    <input type="submit" value="Enviar">
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>