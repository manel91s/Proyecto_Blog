<?php $__env->startSection('section'); ?>



<?php for($i=0; $i< sizeof($featuredPosts); $i++): ?>
    <article class="padding-80px-bottom">
        
        <img src="<?php echo e(asset('images/'.$featuredPosts[$i]->image)); ?>" alt="">
        <div>
        <h1><?php echo e($featuredPosts[$i]->title); ?></h1>
        <p>Genero : <span class="text-bold"><?php echo e($featuredPosts[$i]->name_category); ?></span></p>
        <p><?php echo e(substr($featuredPosts[$i]->body,0,400)); ?>...</p>

        <p>Posteado por: <span class="text-bold"><?php echo e($featuredPosts[$i]->name_user); ?></span></p>
        
        <a class="btn-read" href="<?php echo e(route('detail.post',$featuredPosts[$i]->id)); ?>">Continuar Leyendo</a>
        </div>
    </article>
<?php endfor; ?>


<?php echo e($featuredPosts->links()); ?>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>