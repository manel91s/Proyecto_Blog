<?php $__env->startSection('aside'); ?>

<h1>hola</h1>

<?php echo $__env->yieldSection(); ?>