<!DOCTYPE html>

<html lang="es" class=<?php echo e($pageName); ?> data-page="<?php echo e($dataPage); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Blog Final - <?php echo $__env->yieldContent('titulo'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo e(asset('js/script.min.js')); ?>"></script>
</head>

<body>

    <!--HEADER-->
    <?php echo $__env->make('layout-front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!--CONTAINER SECTION & ASIDE -->
    <div class="container">

    <?php echo $__env->make('layout-front.display_search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
        <section>
            <?php echo $__env->yieldContent('section'); ?>
        </section>

        <!--ASIDE-->
        <?php echo $__env->make('layout-front.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

        <!--FOOTER-->
        <?php echo $__env->make('layout-front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<script type="text/javascript">
     window.CSRF_TOKEN = '<?php echo e(csrf_token()); ?>';
</script>