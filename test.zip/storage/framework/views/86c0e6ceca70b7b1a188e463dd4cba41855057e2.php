<?php $__env->startSection('section'); ?>



<form action="<?php echo e(action('UserController@create')); ?>" method="post" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>

    <p>
        <label for="name">Nombre</label>
        <input type="text" name="name" placeholer="Nombre">
        <p class="alert-warning"><?php echo e($errors->first('name')); ?></p>
    </p>

    <p class="margin-10px-top">
        <label for="surname">Apellidos</label>
        <input type="text" name="surname" placeholer="Apellidos">
        <p class="alert-warning"><?php echo e($errors->first('surname')); ?></p>

    </p>

    <p class="margin-10px-top">
        <label for="email">email</label>
        <input type="email" name="email" placeholer="Email">
        <p class="alert-warning"><?php echo e($errors->first('email')); ?></p>
    </p>

    <p class="margin-10px-top">
        <label for="password">password</label>
        <input type="password" name="password" placeholer="password">
        <p class="alert-warning"><?php echo e($errors->first('password')); ?></p>
    </p>

    

    <p class="margin-10px-top">
        <label for="image">Imagen</label><br/>
        <input type="file" name="image" placeholer="url">
        <p class="alert-warning"><?php echo e($errors->first('image')); ?></p>
    </p>
    

    <?php if(Session::has('success_message')): ?>
        <p class="alert-success"><?php echo e(Session::get('success_message')); ?></p>
    <?php endif; ?>

    <input type="submit" value="Enviar">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>