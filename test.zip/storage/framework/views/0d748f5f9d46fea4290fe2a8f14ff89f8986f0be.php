<?php $__env->startSection('section'); ?>




<form action="<?php echo e(action('UserController@update')); ?>" method="post" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>


    <input type="hidden" name="id" value="<?php echo e($infoUser ? $infoUser->id : ''); ?>" >
    <p>
        <label for="name">Nombre</label>
        <input type="text" name="name" placeholer="Nombre" value="<?php echo e($infoUser ? $infoUser->name : ''); ?>" >
    </p>

    <p class="margin-10px-top">
        <label for="surname">Apellidos</label>
    <input type="text" name="surname" placeholer="Apellidos" value="<?php echo e($infoUser ? $infoUser->surname : ''); ?>">


    </p>

    <p class="margin-10px-top">
        <label for="email">email</label>
        <input type="email" name="email" placeholer="Email" value="<?php echo e($infoUser ? $infoUser->email : ''); ?>">
        <p class="alert-warning"><?php echo e($errors->first('email')); ?></p>
  
    </p>

    <p class="margin-10px-top">
        <label for="password">New password</label>
        <input type="password" name="password" placeholer="password">
        <p class="alert-warning"><?php echo e($errors->first('password')); ?></p>

    </p>

    

    <p class="margin-10px-top">
        <label for="image">Imagen</label><br/>
        <input type="file" name="image" placeholer="url">
        <input type="hidden" name="update_image" value="<?php echo e($infoUser ? $infoUser->avatar_url : ''); ?>">
    </p>
    

    <?php if(Session::has('success_message')): ?>
        <p class="alert-success"><?php echo e(Session::get('success_message')); ?></p>
    <?php endif; ?>

    <input type="submit" value="Enviar">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-front.layout_front', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>