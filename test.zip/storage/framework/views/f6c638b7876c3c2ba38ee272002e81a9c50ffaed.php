<?php use App\Custom\Utils ?>
<aside>
    <div>

        <div class="padding-80px-bottom d-xs-none">
            <h2>Buscar.</h2>
            <form action="" method="" id="form-search">
                <input class="margin-10px-bottom" type="text" id="search" name="search" placeholder="Buscar pelicula">
                <input type="submit" value="Enviar">
                <div id="div1"></div>
            </form>
        </div>

        <div class="padding-80px-bottom margin-50px-xs-top">

            <h2>Categorias.</h2>
            <?php $categorys = Utils::showCategorias() ?>
            <ul>
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('detail.category',$category->id)); ?>"><?php echo e($category->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>

        <div class="padding-80px-bottom">
            <?php if(!session()->has('login')): ?>
            <h2>Login.</h2>
            <form action="<?php echo e(action('UserController@login')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <p>
                    <input type="text" name="email" placeholder="Ponga aqui su email">
                    <p class="alert-warning"><?php echo e($errors->first('email')); ?></p>
                </p>

                <p class="margin-5px-top">
                    <input type="password" name="password" placeholder="Ponga aqui su password">
                    <p class="alert-warning"><?php echo e($errors->first('password')); ?></p>
                </p>

                <?php if(Session::has('login_failed')): ?>
                <p class="alert-warning"><?php echo e(Session::get('login_failed')); ?></p>
                <?php endif; ?>

                <div class="content">
                    <p class="margin-5px-top">
                        <input type="submit">
                    </p>


                    <a href="<?php echo e(action('UserController@index')); ?>">Registrate aqui</a>
                </div>
            </form>
        </div>


        <?php endif; ?>



        <?php $user = session('login') ?>

        <?php if($user && $user->id_role==1): ?>
        <?php $roleClass = "photoAdmin"; ?>
        <?php else: ?>
        <?php $roleClass=""; ?>
        <?php endif; ?>

        <?php if(session()->has('admin') && session()->has('login')): ?>


        <div class="padding-40px-bottom">

            <h2>Panel de Usuario.</h2>

            <?php $realImage = Utils::showImage($user->id) ?>

            <?php if($realImage && $user->avatar_url!=$realImage->avatar_url): ?>
            <img class="avatar_image <?php echo e($roleClass); ?>" src="<?php echo e(asset('avatar_img/'.$realImage->avatar_url)); ?>" alt="">
            <?php elseif($user->avatar_url!=null): ?>
            <img class="avatar_image <?php echo e($roleClass); ?>" src="<?php echo e(asset('avatar_img/'.$user->avatar_url)); ?>" alt="">
            <?php else: ?>
            <img class="" src="" alt="">
            <?php endif; ?>

            <div class="info-user">
                <i class="fa fa-user padding-20px-bottom" aria-hidden="true"></i><span class="text-bold">
                    <?=$user->name ." ". $user->surname?></span>

                <ul>
                    <li><a href="<?php echo e(route('update.user',$user->id)); ?>">Gestionar Perfil</a></li>
                    <li><a class="" href="<?php echo e(action('CategoryController@index')); ?>">Crear categorias</a></li>
                    <li><a class="" href="<?php echo e(action('PostController@create')); ?>">Crear entrada</a></li>
                    <li><a href="<?php echo e(action('PostController@managament')); ?>">Gestionar Entradas</a></li>
                    <li><a class="" href="<?php echo e(action('UserController@logout')); ?>">Cerrar Session</a></li>
                </ul>
            </div>

        </div>

        <?php elseif(session()->has('login')): ?>

        <?php $realImage = Utils::showImage($user->id) ?>

        <div>
            <h2>Panel de Usuario.</h2>

            <?php if($realImage && $user->avatar_url!=$realImage->avatar_url): ?>
            <img class="avatar_image <?php echo e($roleClass); ?>" src="<?php echo e(asset('avatar_img/'.$realImage->avatar_url)); ?>" alt="">
            <?php elseif($user->avatar_url!=null): ?>
            <img class="avatar_image <?php echo e($roleClass); ?>" src="<?php echo e(asset('avatar_img/'.$user->avatar_url)); ?>" alt="">
            <?php else: ?>
            <img class="" src="" alt="">
            <?php endif; ?>

            <div class="info-user">
                <i class="fa fa-user padding-20px-bottom" aria-hidden="true"></i><span class="text-bold">
                    <?=$user->name ." ". $user->surname?></span>
                <ul>

                    <li><a href="<?php echo e(route('update.user',$user->id)); ?>">Gestionar Perfil</a></li>
                    <li><a href="<?php echo e(action('UserController@logout')); ?>">Cerrar Sesion</a></li>

                </ul>
            </div>

        </div>

        <?php endif; ?>

        <div>




</aside>