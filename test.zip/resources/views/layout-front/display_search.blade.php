
<div class="padding-80px-bottom d-lg-block">
            <h2>Buscar.</h2>
            <form action="" method="GET" id="form-searchxs">
            <input type="text" id="searchxs" name="search" placeholder="Buscar pelicula"> 
            <input type="submit" value="Enviar">
            <div id="div2"></div>
            </form>  
</div>