<footer>
        <h2>Blog</h2>
        <p>&copy; Blog.com - Todos los derechos reservados - <span>Desarrollado por Manel</span></p>
        <div>
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-linkedin"></a>
            <a href="#" class="fa fa-instagram"></a>
        </div>

    </footer>