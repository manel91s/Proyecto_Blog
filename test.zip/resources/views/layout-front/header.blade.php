<header>

     <nav>
                 
            <h1 id="logo">Blog</h1>
        
            <a href="{{ action('PostController@index') }}">Inicio</a>
            <a href="{{ action('AboutController@index') }}">Acerca de </a>
            <a href="">Contacto</a>
        
         
     </nav>
     <img id="hamburguesa" src="{{ asset('images/rayitas.svg') }}">
     
 </header>